//
//  Word.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/17.
//

import Foundation
import SwiftData

@Model
class Word {
    
    private var firstWord: String
    var japanese: String?
    var phoneticSymbols: String
    var wordType: [String]
    var verbType: String?
    var chinese: String
    var example: String?
    
    init(
        japanese: String?,
        phoneticSymbols: String,
        wordType: [String],
        verbType: String?,
        chinese: String,
        example: String?
    ) {
        self.firstWord = String(describing: phoneticSymbols.lowercased().first)
        self.japanese = japanese
        self.phoneticSymbols = phoneticSymbols
        self.wordType = wordType
        self.verbType = verbType
        self.chinese = chinese
        self.example = example
    }
}

extension Word: Identifiable {
    var id: UUID { UUID() }
}
