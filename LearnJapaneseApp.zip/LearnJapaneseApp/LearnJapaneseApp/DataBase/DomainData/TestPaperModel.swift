//
//  TestPaperModel.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/03/21.
//

import Foundation

struct TestPaperModel: Codable {
    var question: String
    var option1: String
    var option2: String
    var option3: String
    var option4: String
    var choice: String
    var answer: String
}

extension TestPaperModel: Identifiable {

    var id: String {
        question
    }
}
