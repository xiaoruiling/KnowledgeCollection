//
//  TestRecord.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/03/31.
//
import SwiftData

@Model
class TestRecord {

    @Attribute(.unique) var questionID: String
    var correctNum: Int
    var errorNum: Int

    init(
        questionID: String,
        correctNum: Int,
        errorNum: Int
    ) {
        self.questionID = questionID
        self.correctNum = correctNum
        self.errorNum = errorNum
    }
}

extension TestRecord: Identifiable {
    var id: String {
        questionID
    }
}
