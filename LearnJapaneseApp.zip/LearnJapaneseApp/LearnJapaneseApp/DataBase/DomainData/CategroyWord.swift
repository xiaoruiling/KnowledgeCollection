//
//  CategroyWord.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/20.
//

import Foundation

struct CategroyWord: Codable {
    
    var japanese: String?
    var phoneticSymbols: String
    var wordType: [String]
    var verbType: String?
    var chinese: String
    var example: String?
}
