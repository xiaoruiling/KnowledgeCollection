//
//  LJDataBaseManager+TestRecord.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/03/31.
//

import Foundation
import SwiftData

extension LJDataBaseManager {

    func fetchTestRecord(with questionID: String) throws -> TestRecord? {

        var upcomingTrips = FetchDescriptor<TestRecord>()
//        upcomingTrips.fetchLimit = 50
        upcomingTrips.includePendingChanges = true
        let results1: [TestRecord] = try sharedModelContainer.mainContext.fetch(upcomingTrips)

        let predicate = #Predicate<TestRecord> { $0.questionID == questionID }
        let descriptor = FetchDescriptor(predicate: predicate)

        do {
            let results = try sharedModelContainer.mainContext.fetch(descriptor)
            return results.first
        } catch {
            print("Fetch error: \(error)")
            return nil
        }
    }

    func insert(with testRecord: TestRecord) {
        sharedModelContainer.mainContext.insert(testRecord)
    }
}
