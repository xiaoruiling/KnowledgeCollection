//
//  LJDataBaseManager.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/17.
//

import Foundation
import SwiftUI
import SwiftData

@MainActor
class LJDataBaseManager {
     
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            TestRecord.self
        ])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)

        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()
    
    static let shared: LJDataBaseManager = LJDataBaseManager()
    
    func loadResourcesFile() {
        do {
            let results = try fetchAllWordData()
            if results.isEmpty {
                insertResources()
            }
        } catch {
            
        }
    }
    
    func fetchAllWordData() throws -> [Word] {
        var upcomingTrips = FetchDescriptor<Word>()
//        upcomingTrips.fetchLimit = 50
        upcomingTrips.includePendingChanges = true
        let results: [Word] = try sharedModelContainer.mainContext.fetch(upcomingTrips)
        return results
    }
    
    func insert(with word: Word) {
        insertWordJsonFile(with: word)
        sharedModelContainer.mainContext.insert(word)
    }
    
    func deleteAll() {
        do {
            try sharedModelContainer.mainContext.delete(model: Word.self)
        } catch {
            
        }
    }
    
    func insertWordJsonFile(with word: Word) {
        // 定义 JSON 文件路径
        let filePath = "Word.json"
         
        // 尝试读取 JSON 文件
        guard let file = Bundle.main.url(forResource: filePath, withExtension: nil)
            else {
                fatalError("Couldn't find \(filePath) in main bundle.")
        }
        
        // 获取当前目录的路径
        let fileManager = FileManager.default
        let currentDirectoryURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!

        // 创建文件路径
        let fileURL = currentDirectoryURL.appendingPathComponent("Word.json")
        
        if !fileManager.fileExists(atPath: fileURL.path) {
            let jsonData: Data
            do {
                jsonData = try Data(contentsOf: file)
            } catch {
                fatalError("Cannot get jsonData ")
            }
            
            fileManager.createFile(atPath: fileURL.path, contents: jsonData, attributes: nil)
        }
        
        let jsonData: Data
        do {
            jsonData = try Data(contentsOf: fileURL)
        } catch {
            fatalError("Cannot get jsonData ")
        }
        // 将 jsonData 转换为 [String: Any] 字典
        do {
            var jsonObject = try JSONSerialization.jsonObject(with: jsonData, options: []) as! [String: Any]
         
            // 获取 "word" 数组
            guard let wordArray = jsonObject["word"] as? [[String: Any]] else {
                fatalError("Cannot find 'word' array")
            }
         
            // 创建新的人员信息字典
            let newWord: [String : Any] = [
                "japanese": word.japanese ?? "",
                "phoneticSymbols": word.phoneticSymbols,
                "wordType": word.wordType,
                "verbType": word.verbType ?? "",
                "chinese": word.chinese,
                "example": word.example ?? "",
            ]
            // 将新的人员信息插入到 "word" 数组中
            jsonObject["word"] = wordArray + [newWord]
         
            // 将修改后的 JSON 对象转换回 Data
            let updatedJsonData = try JSONSerialization.data(withJSONObject: jsonObject, options: [])
         
            // 将更新后的 JSON 数据写回文件
            do {
                // 写入文件
                try updatedJsonData.write(to: fileURL)
                print("数据已成功写入 \(fileURL.path) 文件。")
            } catch {
                print("写入文件失败: \(error.localizedDescription)")
            }
        } catch {
            print("Error inserting data: \(error)")
        }
    }
    
    func insertResources() {
        for filePath in filePathArr {
            // 定义 JSON 文件路径
            let filePath = "\(filePath)_Word.json"
             
            // 尝试读取 JSON 文件
            if let file = Bundle.main.url(forResource: filePath, withExtension: nil),
               let jsonData = try? Data(contentsOf: file),
               let jsonObject: [String: Any] = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
               let wordArray = jsonObject["word"] as? [[String: Any]] {
                let _ = wordArray.compactMap { wordJson in
                    let word = Word(
                        japanese: wordJson["japanese"] as? String ?? "",
                        phoneticSymbols: wordJson["phoneticSymbols"] as? String ?? "",
                        wordType: wordJson["wordType"] as? [String] ?? [],
                        verbType: wordJson["verbType"] as? String,
                        chinese: wordJson["chinese"] as? String ?? "",
                        example: wordJson["example"] as? String
                    )
                    sharedModelContainer.mainContext.insert(word)
                }
            } else {
                continue
            }
        }
    }
}


