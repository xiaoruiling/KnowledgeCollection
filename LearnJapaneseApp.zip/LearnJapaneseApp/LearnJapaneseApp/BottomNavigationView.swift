//
//  BottomNavigationView.swift
//  travel
//
//  Created by Elmasry, Essam | Essam | TDD on 2024/08/20.
//

import SwiftUI

struct BottomNavigationView: View {
    
    enum Tab: Int {
        case home
        case books
        case days
        case testPaper
        case japanese
    }
    
    @State private var activeTab: Tab = .home
    @State private var scrollToTopHome: Bool = false
    @StateObject private var homeRouter: LJAppRouter = LJAppRouter(with: NavigationPath())

    // navigation to root is built in in iOS 18
    // TODO: remove implementation when min version is iOS 18
    var tabSelection: Binding<Tab> {
        return .init {
            return activeTab
        } set: { newValue in
            if newValue == activeTab {
                switch newValue {
                case .home:
                    if homeRouter.isRoot {
                        scrollToTopHome = true
                    } else {
                        homeRouter.popToRoot()
                    }
                case .books: print("go to campaign root")
                case .days: print("go to bookmark root")
                case .testPaper: print("go to reservations root")
                case .japanese: print("go to reservations root")
                }
            }
            activeTab = newValue
        }
    }

    var body: some View {
        TabView(selection: tabSelection) {

            NavigationControllerWrapper {
                HomePageView()
               }
            .tabItem {
                   Image(uiImage: activeTab == .home ? UIImage(systemName: "house.fill")! : UIImage(systemName: "house")!)
                   Text("home")
               }
               .tag(Tab.home)


            JapaneseQuestionView()
                .tabItem {
                    Image(uiImage: activeTab == .japanese ? .actions : .actions)
                    Text("japanese")
                }
                .tag(Tab.japanese)
                .tag(Tab.books)
            DaysView()
                .tabItem {
                    Image(uiImage: activeTab == .days ? UIImage(systemName: "star.fill")! : UIImage(systemName: "star")!)
                    Text("Days")
                }
                .tag(Tab.days)
            TestPaperView()
                .tabItem {
                    Image(uiImage: activeTab == .testPaper ? .add : .add)
                    Text("testPaper")
                }
                .tag(Tab.testPaper)

            BooksView()
                .tabItem {
                    Image(uiImage: activeTab == .books ? UIImage(systemName: "book.fill")! : UIImage(systemName: "book")!)
                    Text("Book")
                }
        }
        .onAppear {
            UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14.0)], for: .normal)
            UITabBar.appearance().unselectedItemTintColor = UIColor.black
//            LJDataBaseManager.shared.loadResourcesFile()
        }
        .accentColor(Color(uiColor: .red))
    }
}

#Preview {
    BottomNavigationView()
}

struct PlaceholderTabView: View {
    
    var title: String
    
    var body: some View {
        Text(title)
    }
}

//struct NavigationControllerWrapper<Content: View>: UIViewControllerRepresentable {
//
//    let content: Content
//
//    init(@ViewBuilder content: () -> Content) {
//        self.content = content()
//    }
//
//    func makeUIViewController(context: Context) -> UINavigationController {
//        let root = UIHostingController(rootView: content)
//        let nav = UINavigationController(rootViewController: root)
//
//        nav.setNavigationBarHidden(true, animated: false)
//        nav.interactivePopGestureRecognizer?.isEnabled = true
//        nav.interactivePopGestureRecognizer?.delegate = context.coordinator
//
//        return nav
//    }
//
//    func updateUIViewController(_ uiViewController: UINavigationController, context: Context) {
//        // 绝对不要在这里重新 push 页面，否则手势会失效
//        let root = UIHostingController(rootView: content)
//        uiViewController.setViewControllers([root], animated: false)
//    }
//
//    func makeCoordinator() -> Coordinator {
//        Coordinator()
//    }
//
//    class Coordinator: NSObject, UIGestureRecognizerDelegate {
//        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
//            return true
//        }
//    }
//}


