//
//  BooksView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/01/13.
//

import SwiftUI

struct BooksView: View {
    
    @StateObject private var booksViewLogic = BooksViewLogic()
    
    @StateObject private var appRouter: LJAppRouter = LJAppRouter(with: NavigationPath())

    var body: some View {
        NavigationStack(path: $appRouter.path) {
            VStack(spacing: .zero) {
                LJNavigationView(title: "Books")
            
                List {
                    ForEach(booksViewLogic.books, id: \.self) { book in
                        Text("\(book)")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                appRouter.navigate(to: BooksNavigationRouteType.detail(bookName: book))
                            }
                    }
                }
            }
            .navigationDestination(for: BooksNavigationRouteType.self) { destination in
                switch destination {
                case .detail(let bookName):
                    BookPDFView(urlString: bookName)
                }
            }
        }
        .environmentObject(appRouter)
    }
}

#Preview {
    BooksView()
}
