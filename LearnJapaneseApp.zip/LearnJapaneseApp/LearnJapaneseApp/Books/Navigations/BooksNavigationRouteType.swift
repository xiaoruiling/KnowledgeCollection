//
//  BooksNavigationRouteType.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/18.
//

import Foundation

enum BooksNavigationRouteType: Hashable {
    case detail(bookName: String)
}
