//
//  BooksViewLogic.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/01/13.
//

import Foundation

class BooksViewLogic: ObservableObject {
    
    var books: [String] = [
        "easy_japanese",
        "Collins_Japanese_3000_words_and_phrases"
    ]
}
