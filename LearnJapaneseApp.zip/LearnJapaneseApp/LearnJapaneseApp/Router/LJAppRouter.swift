//
//  LJAppRouter.swift
//  RTNavigation
//
//  Created by liruiling on 2024/12/16.
//

import SwiftUI

public class LJAppRouter: ObservableObject {
    @Published public var path: NavigationPath
    
    public init(with path: NavigationPath) {
        self.path = path
    }

    public func navigate(to destination: any Hashable) {
        path.append(destination)
    }
    
    public func popBack() {
        path.removeLast()
    }
    
    public func popToRoot() {
        path.removeLast(path.count)
    }

    public var isRoot: Bool {
        path.isEmpty
    }
}
