//
//  DaysNavigationRouteType.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/18.
//

import Foundation

enum DaysNavigationRouteType: Hashable {
    case detail(dayFileName: String)
}
