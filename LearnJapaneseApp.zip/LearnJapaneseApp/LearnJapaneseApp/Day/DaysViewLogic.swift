//
//  DaysViewLogic.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/01/23.
//

import Foundation

class DaysViewLogic: ObservableObject {
    
    var days: [String] = [
        "Day1",
        "Day2",
        "Day3",
        "Day4"
    ]
}
