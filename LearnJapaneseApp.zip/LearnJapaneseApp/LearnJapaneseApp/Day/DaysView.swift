//
//  DaysView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/01/23.
//

import SwiftUI

struct DaysView: View {
    
    @StateObject private var daysViewLogic = DaysViewLogic()
    
    @StateObject private var appRouter: LJAppRouter = LJAppRouter(with: NavigationPath())

    var body: some View {
        NavigationStack(path: $appRouter.path) {
            VStack(spacing: .zero) {
                LJNavigationView(title: "Days")
            
                List {
                    ForEach(daysViewLogic.days, id: \.self) { day in
                        Text("\(day)")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                appRouter.navigate(to: DaysNavigationRouteType.detail(dayFileName: day))
                            }
                    }
                }
            }
            .navigationDestination(for: DaysNavigationRouteType.self) { destination in
                switch destination {
                case .detail(let dayFileName):
                    CategroyWordView(filePath: dayFileName)
                }
            }
        }
        .environmentObject(appRouter)
    }
}

#Preview {
    DaysView()
}
