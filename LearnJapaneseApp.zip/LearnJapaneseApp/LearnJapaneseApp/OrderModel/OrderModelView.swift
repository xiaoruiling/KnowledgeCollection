//
//  OrderModelView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/18.
//

import SwiftUI

struct OrderModelView: View {
    var body: some View {
        VStack {

            Text("NoOrderView")
            Spacer()
        }
        .toolbar(content: {
            LJNavigationView(
                title: "顺序模式",
                navigationViewType: .back
            )
            .frame(maxWidth: .infinity, alignment: .leading)
        })
//        .navigationBarHidden(true)
        .frame(maxWidth: .infinity, alignment: .leading)
//        .modifier(EnableSwipeBack())
    }
}

#Preview {
    OrderModelView()
}
