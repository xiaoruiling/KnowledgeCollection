//
//  TestOptionView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/03/21.
//

import SwiftUI

struct TestOptionView: View {

    enum OptionType {
        case selected(index: Int)
        case unSelected(index: Int)
    }

    private let index: Int
    private let option: String
    @Binding var disable: Bool
    @Binding var isNeedClearStatus: Bool
    private let tapOption: ((_ type: OptionType) -> Void)?

    @State private var isSelected: Bool = false

    init(
        index: Int,
        option: String,
        isNeedClearStatus: Binding<Bool>,
        disable: Binding<Bool>,
        tapOption: ((_ type: OptionType) -> Void)?
    ) {
        self.index = index
        self.option = option
        self.tapOption = tapOption
        self._isNeedClearStatus = isNeedClearStatus
        self._disable = disable
    }
    var body: some View {
        HStack(spacing: 16.0) {
            Image(systemName: isSelected ? "checkmark.square" : "square")
                .frame(width: 32.0, height: 32.0)
                .background {
                    disable ? Color.gray : .white
                }
            Text(option)
                .font(Font.system(size: 16.0))
                .frame(maxWidth: .infinity, alignment: .leading)
                .background {
                    disable ? Color.gray : .white
                }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .onTapGesture {
            if !disable {
                isSelected.toggle()
                tapOption?(isSelected ? .selected(index: index) : .unSelected(index: index))
            }
        }
        .onChange(of: isNeedClearStatus) { value in
            isSelected = false
        }
    }
}

#Preview {
    TestOptionView(
        index: 1,
        option: "dfg",
        isNeedClearStatus: .constant(false),
        disable: .constant(false),
        tapOption: nil
    )
}
