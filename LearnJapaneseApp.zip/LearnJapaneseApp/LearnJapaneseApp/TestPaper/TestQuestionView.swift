//
//  TestQuestionView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/03/21.
//

import SwiftUI

struct TestQuestionView: View {

    let questionIndex: Int
    let testQuestion: TestPaperModel

    @State private var isNeedClearStatus: Bool = false
    @State private var option1Disabled: Bool = false
    @State private var option2Disabled: Bool = false
    @State private var option3Disabled: Bool = false
    @State private var option4Disabled: Bool = false

    @Binding var answerType: TestPaperView.AnswerType

    var body: some View {
        VStack(spacing: 16.0) {
            Text("\(questionIndex). \(testQuestion.question)")
                .font(Font.system(size: 18.0, weight: .bold))
                .padding(.horizontal, 24.0)
                .frame(maxWidth: .infinity, alignment: .leading)

            VStack {
                TestOptionView(
                    index: 1,
                    option: testQuestion.option1,
                    isNeedClearStatus: $isNeedClearStatus,
                    disable: $option1Disabled,
                    tapOption: { type in
                        updateQuestionView(type: type)
                        option1Disabled = false
                    }
                )
                TestOptionView(
                    index: 2,
                    option: testQuestion.option2,
                    isNeedClearStatus: $isNeedClearStatus,
                    disable: $option2Disabled,
                    tapOption: { type in
                        updateQuestionView(type: type)
                        option2Disabled = false
                    }
                )
                TestOptionView(
                    index: 3,
                    option: testQuestion.option3,
                    isNeedClearStatus: $isNeedClearStatus,
                    disable: $option3Disabled,
                    tapOption: { type in
                        updateQuestionView(type: type)
                        option3Disabled = false
                    }
                )
                TestOptionView(
                    index: 4,
                    option: testQuestion.option4,
                    isNeedClearStatus: $isNeedClearStatus,
                    disable: $option4Disabled,
                    tapOption: { type in
                        updateQuestionView(type: type)
                        option4Disabled = false
                    }
                )
            }
            .padding(.horizontal, 32.0)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .onChange(of: questionIndex) { index in
            isNeedClearStatus = true
            updateQuestionView(type: .unSelected(index: index))
        }
    }

    private func updateQuestionView(type: TestOptionView.OptionType) {
        switch type {
        case let .selected(index):
            let isAnswer: Bool = "option\(index)" == testQuestion.answer
            answerType = isAnswer ? .correct : .error
            option1Disabled = true
            option2Disabled = true
            option3Disabled = true
            option4Disabled = true
        case let .unSelected(index):
            answerType = .unSelected
            option1Disabled = false
            option2Disabled = false
            option3Disabled = false
            option4Disabled = false
        }
    }
}
