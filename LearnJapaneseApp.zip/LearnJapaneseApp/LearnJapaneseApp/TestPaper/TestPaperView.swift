//
//  TestPaperView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/03/21.
//

import SwiftUI

struct TestPaperView: View {

    enum AnswerType {
        case correct
        case error
        case unSelected
    }
    private let tests: [TestPaperModel] = load("202107TestPaper.json")

    @State private var questionIndex: Int = 0
    @State private var answerType: AnswerType = .unSelected
    @State private var currentTestRecord: TestRecord?

    var body: some View {
        VStack(spacing: 16.0) {
            switch answerType {
            case .correct:
                Text("正确")
                    .font(Font.system(size: 18.0, weight: .bold))
                    .foregroundStyle(.green)
                    .padding(.horizontal, 24.0)
                    .frame(maxWidth: .infinity, alignment: .leading)
            case .error:
                Text("错误")
                    .font(Font.system(size: 18.0, weight: .bold))
                    .foregroundStyle(.red)
                    .padding(.horizontal, 24.0)
                    .frame(maxWidth: .infinity, alignment: .leading)
            case .unSelected:
                Text(" ")
                    .font(Font.system(size: 18.0, weight: .bold))
                    .padding(.horizontal, 24.0)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            HStack {
                Text("正确次数：\(currentTestRecord?.correctNum ?? 0)")
                    .font(Font.system(size: 18.0, weight: .bold))
                    .foregroundStyle(.green)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text("错误次数：\(currentTestRecord?.errorNum ?? 0)")
                    .font(Font.system(size: 18.0, weight: .bold))
                    .foregroundStyle(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(.all, 24.0)
            .frame(maxWidth: .infinity, alignment: .leading)

            TestQuestionView(
                questionIndex: questionIndex + 1,
                testQuestion: tests[questionIndex],
                answerType: $answerType
            )

            HStack {
                if questionIndex != 0 {
                    Button {
                        questionIndex -= 1
                        answerType = .unSelected
                    } label: {
                        Text("上一个")
                            .font(Font.system(size: 18.0))
                            .bold()
                            .foregroundStyle(.black)
                    }
                    .padding(.horizontal, 50)
                    .padding(.vertical, 10)
                    .border(.green, width: 2.0)
                    .cornerRadius(4.0)
                }
                Spacer()
                if questionIndex < tests.count {
                    Button {
                        questionIndex += 1
                        answerType = .unSelected
                    } label: {
                        Text("下一个")
                            .font(Font.system(size: 18.0))
                            .bold()
                            .foregroundStyle(.black)
                    }
                    .padding(.horizontal, 50)
                    .padding(.vertical, 10)
                    .border(.green, width: 2.0)
                    .cornerRadius(4.0)
                }
            }
            .padding(.horizontal, 16.0)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .onAppear {
            currentTestRecord = try? LJDataBaseManager.shared.fetchTestRecord(with: tests[questionIndex].id)
        }
        .onChange(of: answerType) { value in
            updateSaveTestRecord()
        }
        .onChange(of: questionIndex) { index in
            currentTestRecord = try? LJDataBaseManager.shared.fetchTestRecord(with: tests[index].id)
        }
    }

    private func updateSaveTestRecord() {
        let testRecord = currentTestRecord ?? TestRecord(
            questionID: tests[questionIndex].id,
            correctNum: 0,
            errorNum: 0
        )
        switch answerType {
        case .correct:
            testRecord.correctNum += 1
            LJDataBaseManager.shared.insert(with: testRecord)
        case .error:
            testRecord.errorNum += 1
            LJDataBaseManager.shared.insert(with: testRecord)
        case .unSelected:
            break
        }
    }
}

#Preview {
    TestPaperView()
}
