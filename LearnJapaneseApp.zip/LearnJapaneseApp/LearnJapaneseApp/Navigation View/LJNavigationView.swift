//
//  LJNavigationView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/16.
//

import SwiftUI

struct LJNavigationView: View {
    
    enum NavigationViewType {
        case none
        case back
    }
    
    private let title: String
    private let navigationViewType: NavigationViewType
    private let allSpeakAction: (() -> Void)?
    
    @EnvironmentObject var appRoute: LJAppRouter
    
    init(
        title: String,
        navigationViewType: NavigationViewType = .none,
        allSpeakAction: (() -> Void)? = nil
    ) {
        self.title = title
        self.navigationViewType = navigationViewType
        self.allSpeakAction = allSpeakAction
    }
    
    var body: some View {
        ZStack {
            if navigationViewType != .none {
                HStack {
                    Image(.headerBack)
                        .padding(.horizontal, 16.0)
                        .onTapGesture {
                            appRoute.popBack()
                        }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .zIndex(1)
            }
            
            VStack(alignment: .leading, spacing: .zero) {
                Text(title)
                    .font(Font.system(size: 20.0))
                    .bold()
                    .frame(height: 44.0)
            }
            .padding(.horizontal, 44.0)
            
            if let allSpeakAction {
                HStack {
                    Button("All Speak") {
                        allSpeakAction()
                    }
                    .padding(.horizontal, 16.0)
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                .zIndex(1)
            }
        }
        .frame(maxWidth: .infinity)
        .background(.white)
        .compositingGroup()
        .shadow(color: .black.opacity(0.06), radius: 1, x: 0, y: 2)
    }
}

#Preview {
    LJNavigationView(title: "Home")
}
