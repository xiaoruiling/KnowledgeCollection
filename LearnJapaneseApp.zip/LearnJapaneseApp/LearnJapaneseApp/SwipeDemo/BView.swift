import SwiftUI

struct BView: View {
    var body: some View {
        VStack {
            Text("B View (隐藏导航栏仍可侧滑返回)")
                .padding()
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}
