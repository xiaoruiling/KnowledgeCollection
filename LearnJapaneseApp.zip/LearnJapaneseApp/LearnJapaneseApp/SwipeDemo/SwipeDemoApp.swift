import SwiftUI

//@main
//struct SwipeDemoApp: App {
//    var body: some Scene {
//        WindowGroup {
//            TabView {
//                NavigationControllerWrapper {
//                    HomeView()
//                }
//                .tabItem {
//                    Label("Home", systemImage: "house")
//                }
//            }
//        }
//    }
//}
