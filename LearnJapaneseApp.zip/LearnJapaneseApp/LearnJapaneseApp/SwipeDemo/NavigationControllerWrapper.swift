import SwiftUI

struct NavigationControllerWrapper<Content: View>: UIViewControllerRepresentable {

    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    func makeUIViewController(context: Context) -> UINavigationController {
        let root = UIHostingController(rootView: content)
        let nav = UINavigationController(rootViewController: root)

        nav.setNavigationBarHidden(true, animated: false)
        nav.interactivePopGestureRecognizer?.isEnabled = true
        nav.interactivePopGestureRecognizer?.delegate = context.coordinator

        return nav
    }

    func updateUIViewController(_ uiViewController: UINavigationController, context: Context) {
        let root = UIHostingController(rootView: content)
        uiViewController.setViewControllers([root], animated: false)
    }

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            return true
        }
    }
}
