import SwiftUI

struct HomeView: View {
    @State private var path: [String] = []

    var body: some View {
        NavigationStack(path: $path) {
            VStack(spacing: 30) {
                Text("Home View")
                Button("Go to BView") {
                    path.append("B")
                }
            }
            .navigationDestination(for: String.self) { str in
                if str == "B" { BView() }
            }
        }
    }
}
