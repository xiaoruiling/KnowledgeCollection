//
//  WordListRowView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/20.
//

import SwiftUI
import Translation
import AVFoundation

struct WordListRowView: View {
    
    let index: Int
    let japanese: String
    let phoneticSymbols: String
    let chinese: String
    let example: String?
    
    let synthesizer = AVSpeechSynthesizer()
    
    @State private var showTranslation = false

    var body: some View {
        VStack {
            HStack {
                Text("\(index).")
                    .foregroundStyle(.black)
                    .font(Font.system(size: 16.0))
                    .bold()
                Text("\(japanese) [\(phoneticSymbols)] :    \(chinese)")
                    .bold()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .onTapGesture {
                        showTranslation.toggle()
                    }
                    .translationPresentation(isPresented: $showTranslation, text: japanese)
                Spacer()
                Button("Speak") {
                    speakWord(word: japanese)
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
//                        speakWord(word: chinese, language: "zh-CN")
//                    })
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
            if let example, !example.isEmpty {
                VStack {
                    Text("\(example)")
                        .font(Font.system(size: 14.0))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.all, 16.0)
                }
                .overlay(
                    RoundedRectangle(cornerRadius: 24.0)
                        .inset(by: 0.5)
                        .stroke(Color(.primaryContainerVariant), lineWidth: 2)
                )
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    func speakWord(word: String, language: String = "ja-JP") {
        let utterance = AVSpeechUtterance(string: word)
        utterance.voice = AVSpeechSynthesisVoice(language: language) // 设置日语发音
        utterance.rate = 0.5 // 调整语速
        synthesizer.speak(utterance)
    }
}

#Preview {
    WordListRowView(
        index: 1,
        japanese: "愛",
        phoneticSymbols: "あい",
        chinese: "爱情",
        example: "example"
    )
}
