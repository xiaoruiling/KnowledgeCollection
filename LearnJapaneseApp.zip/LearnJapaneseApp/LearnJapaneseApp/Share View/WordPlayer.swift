//
//  AutoPlayer.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/01/21.
//

import Foundation
import AVFAudio

class WordPlayer {
    private var words: [CategroyWord] // 单词数组
    private var currentIndex: Int = 0 // 当前播放索引
    private var timer: DispatchSourceTimer? // 定时器
    private let synthesizer = AVSpeechSynthesizer()

    init(words: [CategroyWord]) {
        self.words = words
    }
    
    // 开始播放
    func startPlaying(interval: TimeInterval) {
        guard !words.isEmpty else {
            print("单词列表为空")
            return
        }
        
        stopPlaying() // 防止重复启动
        
        // 创建 DispatchSourceTimer
        let queue = DispatchQueue.global()
        timer = DispatchSource.makeTimerSource(queue: queue)
        timer?.schedule(deadline: .now(), repeating: interval)
        timer?.setEventHandler { [weak self] in
            self?.playNext()
        }
        timer?.resume() // 启动定时器
    }
    
    // 停止播放
    func stopPlaying() {
        timer?.cancel()
        timer = nil
    }
    
    // 播放下一个单词
    private func playNext() {
        guard !words.isEmpty else { return }
        let word = words[currentIndex].japanese ?? ""
        print("播放单词: \(word)")
        speakWord(word: word)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.3) {
            let chinese = self.words[self.currentIndex].chinese
            if !chinese.isEmpty {
                self.speakWord(word: chinese, language: "zh-CN")
            }
            self.currentIndex = (self.currentIndex + 1) % self.words.count // 循环播放
        }
    }
    
    private func speakWord(word: String, language: String = "ja-JP") {
        let utterance = AVSpeechUtterance(string: word)
        utterance.voice = AVSpeechSynthesisVoice(language: language) // 设置日语发音
        utterance.rate = 0.5 // 调整语速
        synthesizer.speak(utterance)
    }
}
