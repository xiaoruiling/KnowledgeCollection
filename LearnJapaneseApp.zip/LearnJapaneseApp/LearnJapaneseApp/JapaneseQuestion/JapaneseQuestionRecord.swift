//
//  JapneseQuestionRecord.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/04/18.
//

import Foundation
import SwiftData

@Model
final class JapaneseQuestionRecord {
    var questionID: Int  // 题目唯一ID
    var correctNum: Int  // 正确次数
    var errorNum: Int    // 错误次数

    init(questionID: Int, correctNum: Int = 0, errorNum: Int = 0) {
        self.questionID = questionID
        self.correctNum = correctNum
        self.errorNum = errorNum
    }
}
