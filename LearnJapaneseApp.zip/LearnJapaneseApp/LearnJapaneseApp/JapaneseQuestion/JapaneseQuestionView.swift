//
//  JapaneseQuestionView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/04/18.
//

import SwiftUI

struct JapaneseQuestionView: View {

    @State private var questions: [JapaneseQuestionModel] = []
    @State private var currentIndex: Int = 0
    @State private var selectOption: JapaneseQuestionOptionModel?
    @State private var currentQuestionRecord: JapaneseQuestionRecord?

    var body: some View {
        ScrollView {
            VStack(spacing: 16.0) {
                LJNavigationView(title: "Question")
                if !questions.isEmpty {
                    recordDegressView
                    recordNumberView
                    // title
                    Text("\(questions[currentIndex].questionID). \(questions[currentIndex].question)")
                        .font(Font.system(size: 18.0, weight: .bold))
                        .padding(.horizontal, 24.0)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    // options
                    JapaneseQuestionOptionView(
                        selectOptionID: selectOption?.optionID,
                        options: questions[currentIndex].options) { option in
                            if let selectOption, selectOption.optionID == option.optionID {
                                self.selectOption = nil
                            } else {
                                selectOption = option
                                let questionID = questions[currentIndex].questionID
                                JapaneseQuestionRecordManager.shared.updateRecord(
                                    questionID: questionID,
                                    isCorrect: isAnswer
                                )
                                currentQuestionRecord = JapaneseQuestionRecordManager.shared.getRecord(for: questionID)
                                if isAnswer {
                                    let oldCurrentIndex = currentIndex
                                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
                                        if self.currentIndex <= self.questions.count && oldCurrentIndex == self.currentIndex {
                                            self.currentIndex += 1
                                        }
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 16.0)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    // operate
                    operationView
                    if selectOption != nil {
                        HStack {
                            Text(isAnswer ? "正确✅" : "错误❌")
                                .font(Font.system(size: 18.0, weight: .bold))
                                .foregroundStyle(isAnswer ? .green : .red)
                                .padding(.horizontal, 24.0)
                            Text("答案：\(questions[currentIndex].answer)")
                                .font(Font.system(size: 18.0, weight: .bold))
                                .foregroundStyle(.red)
                                .padding(.horizontal, 24.0)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        // reason
                        reasonView
                    }
                    Spacer()
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .onAppear {
                questions = load("JapaneseQuestion.json")
                if let index = questions.firstIndex(where: { $0.questionID == JapaneseQuestionRecordManager.shared.lastQuestionID }) {
                    currentIndex = index
                }
                let questionID = questions[currentIndex].questionID
                currentQuestionRecord = JapaneseQuestionRecordManager.shared.getRecord(for: questionID)
            }
            .onChange(of: currentIndex) {
                clear()
            }

        }
    }

    private var recordDegressView: some View {
        HStack {
            Text("进度：\(currentIndex + 1) / \(questions.count)")
                .font(Font.system(size: 18.0, weight: .bold))
                .foregroundStyle(.green)
                .padding(.horizontal, 24.0)
                .frame(maxWidth: .infinity, alignment: .leading)

            Text("回到首题")
                .font(Font.system(size: 18.0))
                .bold()
                .foregroundStyle(.black)
                .contentShape(Rectangle())
                .padding(.horizontal, 50)
                .padding(.vertical, 10)
                .border(.green, width: 2.0)
                .cornerRadius(4.0)
                .contentShape(Rectangle())
                .frame(alignment: .trailing)
                .onTapGesture {
                    currentIndex = 0
                }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var recordNumberView: some View {
        HStack {
            Text("正确次数：\(currentQuestionRecord?.correctNum ?? 0)")
                .font(Font.system(size: 18.0, weight: .bold))
                .foregroundStyle(.green)
                .frame(maxWidth: .infinity, alignment: .leading)
            Text("错误次数：\(currentQuestionRecord?.errorNum ?? 0)")
                .font(Font.system(size: 18.0, weight: .bold))
                .foregroundStyle(.red)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.horizontal, 24.0)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var operationView: some View {
        HStack {
            if currentIndex != 0 {
                Text("上一题")
                    .font(Font.system(size: 18.0))
                    .bold()
                    .foregroundStyle(.black)
                    .padding(.horizontal, 50)
                    .padding(.vertical, 10)
                    .border(.green, width: 2.0)
                    .cornerRadius(4.0)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        currentIndex -= 1
                    }
            }
            Spacer()
            if currentIndex < (questions.count - 1) {
                Text("下一题")
                    .font(Font.system(size: 18.0))
                    .bold()
                    .foregroundStyle(.black)
                    .contentShape(Rectangle())
                    .padding(.horizontal, 50)
                    .padding(.vertical, 10)
                    .border(.green, width: 2.0)
                    .cornerRadius(4.0)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        currentIndex += 1
                    }
            }
        }
        .padding(.horizontal, 16.0)
    }
    // 显示详细解析
    private var reasonView: some View {
        VStack {
            Text("解析：\(questions[currentIndex].chinese)")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
            ForEach(questions[currentIndex].formattedReason, id: \.key) { key, value in
                VStack(alignment: .leading) {
                    Text("\(key)：\(value)")
                        .font(.callout)
                        .padding(.vertical, 2)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .padding(.horizontal, 24.0)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var isAnswer: Bool {
        questions[currentIndex].answer == selectOption?.optionID
    }

    private func clear() {
        selectOption = nil
        let questionID = questions[currentIndex].questionID
        currentQuestionRecord = JapaneseQuestionRecordManager.shared.getRecord(for: questionID)
        JapaneseQuestionRecordManager.shared.lastQuestionID = questionID
    }
}
