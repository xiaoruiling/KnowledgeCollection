//
//  JapaneseQuestionOptionView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/04/18.
//

import SwiftUI

struct JapaneseQuestionOptionView: View {

    private let selectOptionID: Int?
    private let options: [JapaneseQuestionOptionModel]
    private let tapOption: ((_ option: JapaneseQuestionOptionModel) -> Void)?

    init(
        selectOptionID: Int?,
        options: [JapaneseQuestionOptionModel],
        tapOption: ((_ option: JapaneseQuestionOptionModel) -> Void)? = nil
    ) {
        self.selectOptionID = selectOptionID
        self.options = options
        self.tapOption = tapOption
    }

    var body: some View {
        VStack(spacing: .zero) {
            ForEach(options, id: \.optionID) { option in
                HStack(spacing: 8.0) {
                    Image(systemName: isSelected(option: option) ? "checkmark.square" : "square")
                        .frame(width: 32.0, height: 32.0)
                    Text(option.option)
                        .font(Font.system(size: 16.0))
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .onTapGesture {
                    tapOption?(option)
                }
            }
        }
    }

    private func isSelected(option: JapaneseQuestionOptionModel) -> Bool {
        selectOptionID == option.optionID
    }
}
