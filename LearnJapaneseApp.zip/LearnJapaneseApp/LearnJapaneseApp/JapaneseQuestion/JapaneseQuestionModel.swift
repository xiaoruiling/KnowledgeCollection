//
//  JapaneseQuestionModel.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/04/18.
//

import Foundation

struct JapaneseQuestionModel: Codable {
    let questionID: Int
    let question: String
    let options: [JapaneseQuestionOptionModel]
    let answer: Int
    let chinese: String
    let reason: [String: String]

    var formattedReason: [(key: String, value: String)] {
        reason.sorted { $0.key < $1.key }
    }
}

struct JapaneseQuestionOptionModel: Codable {
    var optionID: Int
    var option: String
}

extension JapaneseQuestionModel: Identifiable {

    var id: String {
        "\(questionID)"
    }
}
