//
//  JapaneseQuestionRecordManager.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/04/18.
//

import Foundation
import SwiftData
import SwiftUI

@MainActor
class JapaneseQuestionRecordManager {

    static let shared: JapaneseQuestionRecordManager = JapaneseQuestionRecordManager()

    private let container: ModelContainer
    private let context: ModelContext

    @AppStorage("lastQuestionID") var lastQuestionID: Int?

    init() {
        // 初始化容器
        container = try! ModelContainer(for: JapaneseQuestionRecord.self)
        context = container.mainContext
    }

    // MARK: - 创建或更新记录
    func updateRecord(questionID: Int, isCorrect: Bool) {
        // 查询已有记录
        let descriptor = FetchDescriptor<JapaneseQuestionRecord>(
            predicate: #Predicate { $0.questionID == questionID }
        )

        do {
            let records = try context.fetch(descriptor)

            if let existingRecord = records.first {
                // 更新现有记录
                if isCorrect {
                    existingRecord.correctNum += 1
                } else {
                    existingRecord.errorNum += 1
                }
            } else {
                // 创建新记录
                let newRecord = JapaneseQuestionRecord(questionID: questionID)
                if isCorrect {
                    newRecord.correctNum = 1
                } else {
                    newRecord.errorNum = 1
                }
                context.insert(newRecord)
            }

            try context.save()  // 保存更改
        } catch {
            print("更新记录失败: \(error)")
        }
    }

    // MARK: - 读取单个题目记录
    func getRecord(for questionID: Int) -> JapaneseQuestionRecord? {
        let descriptor = FetchDescriptor<JapaneseQuestionRecord>(
            predicate: #Predicate { $0.questionID == questionID }
        )

        do {
            return try context.fetch(descriptor).first
        } catch {
            print("读取记录失败: \(error)")
            return nil
        }
    }

    // MARK: - 读取所有记录
    func getAllRecords() -> [JapaneseQuestionRecord] {
        let descriptor = FetchDescriptor<JapaneseQuestionRecord>(
            sortBy: [SortDescriptor(\.questionID)]
        )

        do {
            return try context.fetch(descriptor)
        } catch {
            print("读取全部记录失败: \(error)")
            return []
        }
    }

    // MARK: - 重置记录
    func resetRecord(questionID: Int) {
        let descriptor = FetchDescriptor<JapaneseQuestionRecord>(
            predicate: #Predicate { $0.questionID == questionID }
        )

        do {
            if let record = try context.fetch(descriptor).first {
                context.delete(record)
                try context.save()
            }
        } catch {
            print("重置记录失败: \(error)")
        }
    }
}
