//
//  ViewController.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/09/15.
//

import WebKit
import UIKit

class ViewController: UIViewController, WKNavigationDelegate {

    var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // 创建 WKWebView
        webView = WKWebView(frame: view.bounds)
        webView.navigationDelegate = self
        view.addSubview(webView)

        // 加载本地 HTML 文件
        loadLocalHTML()
    }

    func loadLocalHTML() {
        // 获取主 bundle
        let bundle = Bundle.main

        // 假设你的 HTML 文件名为 index.html，位于项目的根目录
        if let htmlPath = bundle.path(forResource: "index", ofType: "html") {
            let htmlUrl = URL(fileURLWithPath: htmlPath)

            // 加载 HTML 文件
            webView.loadFileURL(htmlUrl, allowingReadAccessTo: htmlUrl.deletingLastPathComponent())
        } else {
            print("HTML file not found")
        }
    }

    // WKNavigationDelegate 方法，处理页面加载完成
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("WebView loaded successfully")
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("WebView loading failed: \(error.localizedDescription)")
    }
}
