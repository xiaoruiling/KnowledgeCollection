//
//  MulitpleSelectedPickerView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/18.
//

import SwiftUI

struct MulitpleSelectedPickerView: View {
    
    let title: String
    @Binding var selectedItems: [WordType]

    @State private var isPresented: Bool = false
    
    var body: some View {
        HStack {
            Text(title)
                .font(Font.system(size: 14.0))
            Text(contentString)
                .font(Font.system(size: 13.0))
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
        .onTapGesture {
            isPresented.toggle()
        }
        .sheet(isPresented: $isPresented) {
            PickerItemView(
                items: WordType.allCases,
                selectedItems: $selectedItems,
                isClosed: $isPresented
            )
        }
    }
    
    private var contentString: String {
        selectedItems.reduce("", { $0 + ($0.isEmpty ? "" : "、") + $1.rawValue })
    }
}

private struct PickerItemView: View {
    
    var items: [WordType]
    @Binding var selectedItems: [WordType]
    @Binding var isClosed: Bool
    
    var body: some View {
        
        ScrollView {
            VStack(spacing: .zero) {
                HStack {
                    Image(uiImage: .headerClose)
                        .resizable()
                        .frame(width: 24.0, height: 24.0)
                        .onTapGesture {
                            isClosed.toggle()
                        }
                }
                .padding(.vertical, 16.0)
                .frame(maxWidth: .infinity, alignment: .leading)
                
                ForEach(items, id: \.id) { item in
                    VStack {
                        Divider()
                        HStack {
                            Text(item.rawValue)
                                .font(Font.system(size: 13.0))
                                .frame(maxWidth: .infinity, alignment: .leading)
                            if selectedItems.contains(item) {
                                Image(systemName: "checkmark")
                            }
                        }
                        .padding(.vertical, 16.0)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        if selectedItems.contains(item) {
                            if let index = selectedItems.firstIndex(where: { $0 == item }) {
                                selectedItems.remove(at: index)
                            }
                        } else {
                            selectedItems.append(item)
                        }
                    }
                }
            }
            .padding(.horizontal, 16.0)
        }
    }
}
#Preview {
    MulitpleSelectedPickerView(title: "title", selectedItems: .constant(WordType.allCases))
}
