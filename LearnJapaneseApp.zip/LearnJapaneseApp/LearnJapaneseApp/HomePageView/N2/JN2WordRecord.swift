//
//  JN2WordRecord.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/07/18.
//

import Foundation
import SwiftData

@Model
final class JN2WordRecord {
    var wordID: String
    var correctNum: Int  // 正确次数
    var errorNum: Int    // 错误次数

    init(
        wordID: String,
        correctNum: Int = 0,
        errorNum: Int = 0
    ) {
        self.wordID = wordID
        self.correctNum = correctNum
        self.errorNum = errorNum
    }
}
