//
//  JapaneseN2View.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/07/18.
//

import SwiftUI
import AVFoundation
import WebKit

struct JapaneseN2View: View {

    @State private var jN2Words: [JN2Word] = []
    @State private var currentIndex: Int = 0
    @State private var currentJN2WordRecord: JN2WordRecord?
    @State private var showList: Bool = false
    @State private var showJieXi: Bool = false
    @State private var showTrans: Bool = false
    @State private var skipToIndex: String = ""

    @State private var timer: Timer?
    @State private var autoJieXi: Bool = false

    let synthesizer = AVSpeechSynthesizer()

    var body: some View {
        VStack(spacing: 32.0) {
            controlButtonView
            recordDegressView
            recordView
            wordCardView
            wordOperateView
        }
        .onAppear {
            jN2Words = load("JN2.json")
            if let index = jN2Words.firstIndex(where: { $0.id == JN2WordRecordManager.shared.lastWordID }) {
                currentIndex = index
            }
            let wordID = jN2Words[currentIndex].id
            currentJN2WordRecord = JN2WordRecordManager.shared.getRecord(for: wordID)
        }
        .onChange(of: currentIndex) { oldValue, newValue in
            JN2WordRecordManager.shared.lastWordID = jN2Words[newValue].id
            speakWord(word: jN2Words[newValue].word)
            showTrans = false
            DispatchQueue.main.asyncAfter(
                deadline: DispatchTime.now() + 8,
                execute: {
                    showTrans = true
                }
            )
        }
        .onChange(of: skipToIndex) { oldValue, newValue in
            if let index = Int(skipToIndex) {
                currentIndex = (index - 1)
            }
        }
        .fullScreenCover(isPresented: $showList) {
            JapaneseN2ListView(
                currentIndex: currentIndex,
                jN2Words: jN2Words,
                showList: $showList
            )
        }
        .fullScreenCover(isPresented: $showJieXi) {
            if !jN2Words.isEmpty {
                let word = jN2Words[currentIndex]
                SafariView(url: URL(string: "https://jisho.org/search/\(word.jiaMing)")!)
            }
        }
        .onAppear {
            start()
        }
    }

    private func start() {
        // scheduledTimer 会自动加入当前 RunLoop 的 .default 模式
        timer = Timer.scheduledTimer(withTimeInterval: 15, repeats: true) { _ in
            DispatchQueue.main.async {
                // 计录当前的
                JN2WordRecordManager.shared.updateRecord(
                    wordID: jN2Words[currentIndex].id,
                    isCorrect: false
                )
                if (currentIndex + 1) >= jN2Words.count {
                    currentIndex = 0
                } else {
                    currentIndex += 1
                }
                // 获取下一个
                currentJN2WordRecord = JN2WordRecordManager.shared.getRecord(for: jN2Words[currentIndex].id)
            }

            if autoJieXi {
                DispatchQueue.main.asyncAfter(
                    deadline: DispatchTime.now() + 6,
                    execute: {
                        showJieXi = true
                    }
                )

                DispatchQueue.main.asyncAfter(
                    deadline: DispatchTime.now() + 12,
                    execute: {
                        showJieXi = false
                    }
                )
            }
        }
        // 如果需要在滚动（RunLoop 切换模式）时也继续触发：
        RunLoop.current.add(timer!, forMode: .common)
        timer?.tolerance = 0.3  // 允许 0.3 秒偏差
    }

    private var controlButtonView: some View {
        VStack {
            Button(timer == nil ? "开始" : "暂停") {
                if timer == nil {
                    start()
                } else {
                    timer?.invalidate()
                    timer = nil
                }
            }
            .frame(width: 100, height: 60)

            Button("自动解析: \(autoJieXi ? "开启" : "关闭")") {
                autoJieXi.toggle()
            }
            .frame(width: 200, height: 60)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var recordDegressView: some View {
        VStack {
            HStack {
                Text("进度：\(currentIndex + 1) / \(jN2Words.count)")
                    .font(Font.system(size: 18.0, weight: .bold))
                    .foregroundStyle(.green)
                    .frame(maxWidth: .infinity, alignment: .leading)

                Button("全部") {
                    showList = true
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            HStack {
                Text("跳转到：")
                    .font(Font.system(size: 18.0, weight: .bold))
                    .foregroundStyle(.green)
                    .frame(maxWidth: .infinity, alignment: .leading)
                TextField("请输入数字", text: $skipToIndex)
                    .border(.background, width: 1.0)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.horizontal, 24.0)
    }

    private var recordView: some View {
        HStack {
            Text("正确次数：\(currentJN2WordRecord?.correctNum ?? 0)")
                .font(Font.system(size: 18.0, weight: .bold))
                .foregroundStyle(.green)
                .frame(maxWidth: .infinity, alignment: .leading)
            Text("错误次数：\(currentJN2WordRecord?.errorNum ?? 0)")
                .font(Font.system(size: 18.0, weight: .bold))
                .foregroundStyle(.red)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.horizontal, 24.0)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var wordCardView: some View {
        Group {
            VStack(spacing: 16.0) {
                if !jN2Words.isEmpty {
                    let word = jN2Words[currentIndex]
                    Text(word.word)
                        .font(Font.system(size: 28.0))
                    if showTrans {
                        Text(word.jiaMing)
                            .font(Font.system(size: 28.0))
                        Text(word.trans.joined(separator: ","))
                            .font(Font.system(size: 24.0))
                    }
                    HStack {
                        Button("解析") {
                            showJieXi = true
                        }
                        Spacer()
                        Button("朗读") {
                            speakWord(word: word.word)
                        }
                    }
                    .padding(.all,16.0)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                }
            }
            .padding(.all,16.0)
            .frame(maxWidth: .infinity)
            .frame(height: 300.0)
            .background(.white)
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.24), radius: 6, x: 0, y: 4)
            .padding(.horizontal, 24.0)
        }
    }

    private var wordOperateView: some View {
        HStack {
            Text("会")
                .font(Font.system(size: 18.0))
                .bold()
                .foregroundStyle(.black)
                .padding(.horizontal, 50)
                .padding(.vertical, 10)
                .border(.green, width: 2.0)
                .cornerRadius(4.0)
                .contentShape(Rectangle())
                .onTapGesture {
                    // 计录当前的
                    JN2WordRecordManager.shared.updateRecord(
                        wordID: jN2Words[currentIndex].id,
                        isCorrect: true
                    )
                    currentIndex += 1
                    // 获取下一个
                    currentJN2WordRecord = JN2WordRecordManager.shared.getRecord(for: jN2Words[currentIndex].id)
                }
            Spacer()
            if currentIndex < (jN2Words.count - 1) {
                Text("不会")
                    .font(Font.system(size: 18.0))
                    .bold()
                    .foregroundStyle(.black)
                    .contentShape(Rectangle())
                    .padding(.horizontal, 50)
                    .padding(.vertical, 10)
                    .border(.green, width: 2.0)
                    .cornerRadius(4.0)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        JN2WordRecordManager.shared.updateRecord(
                            wordID: jN2Words[currentIndex].id,
                            isCorrect: false
                        )
                        currentIndex += 1
                        // 获取下一个
                        currentJN2WordRecord = JN2WordRecordManager.shared.getRecord(for: jN2Words[currentIndex].id)
                    }
            }
        }
        .padding(.horizontal, 32.0)
    }

    private func speakWord(word: String, language: String = "ja-JP") {
        let utterance = AVSpeechUtterance(string: word)
        utterance.voice = AVSpeechSynthesisVoice(language: language) // 设置日语发音
        utterance.rate = 0.5 // 调整语速
        synthesizer.speak(utterance)
    }
}

#Preview {
    JapaneseN2View()
}
