//
//  JN2Word.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/07/18.
//

import Foundation

struct JN2Word: Codable {
    let id: String
    let name: String
    let trans: [String]
    let notation: String
}

extension JN2Word {

    var word: String {
        let removeWord = notation.replacingOccurrences(of: "\\(.*?\\)", with: "", options: .regularExpression)
        return removeWord
    }

    var jiaMing: String {
        let re = /(?<kanji>[\p{Han}々〆ヶ]+)[\(（](?<kana>[\p{sc=Hiragana}\p{sc=Katakana}ー]+)[\)）]/
        return notation.replacing(re) { $0.kana }
    }
}

//struct JN2Word1: Codable {
//    let id: String
//    let name: String
//    let trans: [String]
//    let notation: String
//}


//private func test() {
//    if let url = Bundle.main.url(forResource: "JN2", withExtension: "json") {
//        do {
//            let data = try Data(contentsOf: url)
//            var jN2Words = try JSONDecoder().decode([JN2Word].self, from: data)
//
//            var jn2Words1: [JN2Word1] = []
//            // 添加索引
//            for i in 0..<jN2Words.count {
//                let jn21: JN2Word1 = JN2Word1(
//                    id: "\(i)_\(jN2Words[i].name)",
//                    name: jN2Words[i].name,
//                    trans: jN2Words[i].trans,
//                    notation: jN2Words[i].notation
//                )
//                jn2Words1.append(jn21)
//            }
//            // （可选）写回 JSON 文件
//            let updatedData = try JSONEncoder().encode(jn2Words1)
//            let jsonString = String(data: updatedData, encoding: .utf8)
//            print(jsonString ?? "")
//
//        } catch {
//            print("解析错误: \(error)")
//        }
//    }
//}
