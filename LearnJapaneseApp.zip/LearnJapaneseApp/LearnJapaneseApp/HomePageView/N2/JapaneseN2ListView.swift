//
//  JapaneseN2ListView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/07/18.
//

import SwiftUI

struct JapaneseN2ListView: View {

    let currentIndex: Int
    let jN2Words: [JN2Word]

    @State private var showTrans: Bool = false
    @State private var tapIndex: Int = 0

    @Binding var showList: Bool

    var body: some View {
        ScrollViewReader { proxy in
            VStack(alignment: .leading) {
                Button(
                    "关闭",
                    image: .headerBack
                ) {
                    showList = false
                }
                .frame(height: 40.0)
                .padding(.horizontal, 16.0)
                .background(.white)
                List {
                    ForEach(Array(jN2Words.enumerated()), id: \.offset) { (index, word) in
                        HStack {
                            Text("\(index + 1). ")
                            Text("\(word.notation)")
                            if showTrans && tapIndex == index {
                                Spacer()
                                Text("\(word.trans.joined(separator: ","))")
                            }

                        }
                        .id(index)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .onTapGesture(perform: { _ in
                            if showTrans && (tapIndex != index) {
                                tapIndex = index
                            } else {
                                tapIndex = index
                                self.showTrans.toggle()
                            }
                        })
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .onAppear {
                    // 延迟一点执行，以确保 List 已经加载完成
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        withAnimation {
                            proxy.scrollTo(currentIndex, anchor: .center) // 滑动到第 50 行
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

#Preview {
    JapaneseN2ListView(
        currentIndex: 0,
        jN2Words: [],
        showList: .constant(
            true
        )
    )
}
