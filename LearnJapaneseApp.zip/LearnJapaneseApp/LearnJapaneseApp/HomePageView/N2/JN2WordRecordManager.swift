//
//  JN2WordRecordManager.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/07/18.
//

import Foundation
import SwiftData
import SwiftUI

@MainActor
class JN2WordRecordManager {

    static let shared: JN2WordRecordManager = JN2WordRecordManager()

    private let container: ModelContainer
    private let context: ModelContext

    @AppStorage("lastWordID") var lastWordID: String?

    init() {
        // 初始化容器
        container = try! ModelContainer(for: JN2WordRecord.self)
        context = container.mainContext
    }

    // MARK: - 创建或更新记录
    func updateRecord(wordID: String, isCorrect: Bool) {
        // 查询已有记录
        let descriptor = FetchDescriptor<JN2WordRecord>(
            predicate: #Predicate { $0.wordID == wordID }
        )

        do {
            let records = try context.fetch(descriptor)

            if let existingRecord = records.first {
                // 更新现有记录
                if isCorrect {
                    existingRecord.correctNum += 1
                } else {
                    existingRecord.errorNum += 1
                }
            } else {
                // 创建新记录
                let newRecord = JN2WordRecord(wordID: wordID)
                if isCorrect {
                    newRecord.correctNum = 1
                } else {
                    newRecord.errorNum = 1
                }
                context.insert(newRecord)
            }

            try context.save()  // 保存更改
        } catch {
            print("更新记录失败: \(error)")
        }
    }

    // MARK: - 读取单个题目记录
    func getRecord(for wordID: String) -> JN2WordRecord? {
        let descriptor = FetchDescriptor<JN2WordRecord>(
            predicate: #Predicate { $0.wordID == wordID }
        )

        do {
            return try context.fetch(descriptor).first
        } catch {
            print("读取记录失败: \(error)")
            return nil
        }
    }

    // MARK: - 读取所有记录
    func getAllRecords() -> [JN2WordRecord] {
        let descriptor = FetchDescriptor<JN2WordRecord>(
            sortBy: [SortDescriptor(\.wordID)]
        )

        do {
            return try context.fetch(descriptor)
        } catch {
            print("读取全部记录失败: \(error)")
            return []
        }
    }

    // MARK: - 重置记录
    func resetRecord(wordID: String) {
        let descriptor = FetchDescriptor<JN2WordRecord>(
            predicate: #Predicate { $0.wordID == wordID }
        )

        do {
            if let record = try context.fetch(descriptor).first {
                context.delete(record)
                try context.save()
            }
        } catch {
            print("重置记录失败: \(error)")
        }
    }
}
