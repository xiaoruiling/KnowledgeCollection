//
//  HomePageNavigationRouteType.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/18.
//

import Foundation

enum HomePageNavigationRouteType: Hashable {
    case order
    case noOrder
    case categroy(filePath: String)
    case jN2
}
