//
//  AddWordsView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/16.
//

import SwiftUI
import SwiftData

struct AddWordsView: View {
    
    @Binding var isPresented: Bool
    
    enum Field: Hashable {
        case japanese
        case phoneticSymbols
        case chinese
        case example
    }
    
    @State private var japanese = ""
    @State private var phoneticSymbols = ""
    @State private var wordType: [WordType] = [.notSure]
    @State private var verbType: VerbType = .none
    @State private var chinese = ""
    @State private var example = ""
    @FocusState private var focusedField: Field?
    @State private var selection = 0
    
    var body: some View {
        VStack {
            ZStack {
                HStack {
                    Image(uiImage: .headerClose)
                        .resizable()
                        .frame(width: 24.0, height: 24.0)
                        .padding(.horizontal, 16.0)
                        .onTapGesture {
                            isPresented.toggle()
                        }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                Text("add")
                    .frame(maxWidth: .infinity)
            }
            
            Form {
                TextField("日文", text: $japanese)
                    .focused($focusedField, equals: .japanese)
                TextField("音标", text: $phoneticSymbols)
                    .focused($focusedField, equals: .phoneticSymbols)
                
                MulitpleSelectedPickerView(
                    title: "词性",
                    selectedItems: $wordType
                )
                if wordType.contains(.verb1) || wordType.contains(.verb2) || wordType.contains(.verb3) {
                    Picker("动词词性", selection: $verbType) {
                        ForEach(VerbType.allCases, id: \.self) { type in
                            Text(type.rawValue)
                                .bold()
                                .tag(type)
                        }
                    }
                    .pickerStyle(.menu)
                }
                TextField("中文", text: $chinese)
                    .focused($focusedField, equals: .chinese)
                TextField("例句", text: $example)
                    .focused($focusedField, equals: .example)
                
                Button("Add") {
                    if japanese.isEmpty {
                        focusedField = .japanese
                    } else if phoneticSymbols.isEmpty {
                        focusedField = .phoneticSymbols
                    } else {
                        LJDataBaseManager.shared.insert(
                            with: Word(
                                japanese: japanese,
                                phoneticSymbols: phoneticSymbols,
                                wordType: wordType.compactMap({ $0.rawValue }),
                                verbType: verbType.rawValue,
                                chinese: chinese,
                                example: example
                            )
                        )
                        japanese = ""
                        phoneticSymbols = ""
                        wordType = [.notSure]
                        verbType = .none
                        chinese = ""
                        example = ""
                        focusedField = .japanese
                    }
                }
            }
            .onSubmit {
                switch focusedField {
                case .japanese:
                    focusedField = .phoneticSymbols
                case .phoneticSymbols:
                    focusedField = .chinese
                default:
                    break
                }
            }
        }
    }
}

#Preview {
    AddWordsView(isPresented: .constant(true))
}


struct ContentView: View {
    @State private var translationVisible = false
    private var originalText = "Hallo, Welt!"


    var body: some View {
        VStack {
            Text(verbatim: originalText)
                .translationPresentation(isPresented: $translationVisible, text: originalText)
            Button("Translate") {
                translationVisible.toggle()
            }
        }
    }
}

#Preview {
    ContentView()
}
