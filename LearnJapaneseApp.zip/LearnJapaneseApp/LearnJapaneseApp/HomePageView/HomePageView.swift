//
//  HomePageView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/16.
//

import SwiftUI

struct HomePageView: View {
    
    @StateObject private var appRouter: LJAppRouter = LJAppRouter(with: NavigationPath())
    @State private var isPresentAddView: Bool = false
    
    var body: some View {
        NavigationStack(path: $appRouter.path) {
            VStack(spacing: .zero) {
                LJNavigationView(title: "Home")
                
                HStack(spacing: .zero) {
                    Button {
                        isPresentAddView.toggle()
                    } label: {
                        Text("Add")
                            .font(Font.system(size: 18.0))
                            .bold()
                            .foregroundStyle(.black)
                    }
                    .padding(.horizontal, 50)
                    .padding(.vertical, 10)
                    .border(.green, width: 2.0)
                    .cornerRadius(4.0)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.all, 16)
                .contentShape(Rectangle())
                VStack(spacing: 16.0) {
                    Text("顺序模式")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            appRouter.navigate(to: HomePageNavigationRouteType.order)
                        }
                    Divider()
                    Text("无序模式")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            appRouter.navigate(to: HomePageNavigationRouteType.noOrder)
                        }
                    Divider()
                    Text("N2 高频词")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            appRouter.navigate(to: HomePageNavigationRouteType.jN2)
                        }
                }
                .padding(16.0)
                .frame(maxWidth: .infinity, alignment: .leading)
                
                List {
                    ForEach(filePathArr, id: \.self) { filePath in
                        Text("\(filePath)")
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                appRouter.navigate(to: HomePageNavigationRouteType.categroy(filePath: filePath))
                            }
                    }
                }
            }
            .fullScreenCover(isPresented: $isPresentAddView) {
                AddWordsView(isPresented: $isPresentAddView)
            }
            .navigationDestination(for: HomePageNavigationRouteType.self) { destination in
                switch destination {
                case .order:
                    OrderModelView()
                case .noOrder:
                    NoOrderModelView()
                case let .categroy(filePath):
                    CategroyWordView(filePath: filePath)
                case .jN2:
                    JapaneseN2View()
                }
            }
        }
        .environmentObject(appRouter)
        .onAppear {
            loadJsonFileData()
        }
    }
    
    private func loadJsonFileData() {
    }
}

#Preview {
    HomePageView()
        .environmentObject(LJAppRouter(with: NavigationPath()))
}

struct EnableSwipeBack: ViewModifier {
    func body(content: Content) -> some View {
        content
            .background(NavigationConfigurator { nav in
                nav.interactivePopGestureRecognizer?.delegate = nil
                nav.interactivePopGestureRecognizer?.isEnabled = true
            })
    }
}

struct NavigationConfigurator: UIViewControllerRepresentable {
    var configure: (UINavigationController) -> Void

    func makeUIViewController(context: Context) -> UIViewController {
        UIViewController()
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
        if let nav = uiViewController.navigationController {
            configure(nav)
        }
    }
}
