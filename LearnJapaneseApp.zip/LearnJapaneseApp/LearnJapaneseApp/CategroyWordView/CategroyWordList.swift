//
//  CategroyWordList.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/20.
//

import Foundation

struct CategroyWordList: Codable {
    
    var word: [CategroyWord]
}
