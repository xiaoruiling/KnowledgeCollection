//
//  CategroyWordView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/20.
//

import SwiftUI
import SwiftUIOverlayContainer
import Translation

struct CategroyWordView: View {
    
    let filePath: String
    
    @State private var categroyWords: [CategroyWord] = []
    @Environment(\.overlayContainerManager) var manager

    @State private var currentWord: CategroyWord? = nil
    @State private var showExample: Bool = false
    
    @State private var wordPlayer: WordPlayer?
    

    var body: some View {
        VStack(spacing: .zero) {
            LJNavigationView(
                title: filePath,
                navigationViewType: .back,
                allSpeakAction: {
                    allSpeakAction()
                }
            )
            ScrollView {
                VStack(spacing: 16.0) {
                    ForEach(Array(categroyWords.enumerated()), id: \.offset) { (index, word) in
                        if index != 0 || (index != (categroyWords.count - 1) && index > 0) {
                            Divider()
                        }
                        WordListRowView(
                            index: index + 1,
                            japanese: word.japanese ?? "",
                            phoneticSymbols: word.phoneticSymbols,
                            chinese: word.chinese,
                            example: word.example
                        )
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .contentShape(Rectangle())
                    }
                }
                .padding(16.0)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            Spacer()

        }
        .navigationBarHidden(true)
        .frame(maxWidth: .infinity, alignment: .leading)
        .onAppear {
            loadWordData()
        }
    }
    
    private func loadWordData() {
        let list: CategroyWordList = load("\(filePath)_Word.json")
        categroyWords = list.word
    }
    
    private func allSpeakAction() {
        // 使用示例
        wordPlayer = WordPlayer(words: categroyWords)
        // 开始自动播放，每隔 3 秒播放一个单词
        wordPlayer?.startPlaying(interval: 3)
    }
}

#Preview {
    CategroyWordView(filePath: "あ")
}
