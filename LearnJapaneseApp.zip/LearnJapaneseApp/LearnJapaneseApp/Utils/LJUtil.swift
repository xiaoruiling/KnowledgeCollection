//
//  LJUtil.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/17.
//

import Foundation

enum WordType: String, CaseIterable, Identifiable {
    
    case noun
    case verb1
    case verb2
    case verb3
    case イadjective
    case ナadjective
    case adverb
    case conjunctive
    case notSure
    var id: String { self.rawValue }
    
    var rawValue: String {
        switch self {
        case .noun:
            "名词"
        case .verb1:
            "1 类动词"
        case .verb2:
            "2 类动词"
        case .verb3:
            "3 类动词"
        case .イadjective:
            "イ 型形容词"
        case .ナadjective:
            "ナ 型形容词"
        case .adverb:
            "副词"
        case .conjunctive:
            "连词"
        case .notSure:
            "不确定"
        }
    }
}

enum VerbType: String, CaseIterable {
    case none
    case intransitive
    case transitive
    case all
    
    var rawValue: String {
        switch self {
        case .none:
            ""
        case .intransitive:
            "自动词"
        case .transitive:
            "他动词"
        case .all:
            "自他动词"
        }
    }
}

let filePathArr: [String] = [
    "常用动词",
    "常用形容词",
    "连词",
    "あ",
    "い",
    "し",
    "き",
    "天気",
    "環境",
    "呼救"
]
