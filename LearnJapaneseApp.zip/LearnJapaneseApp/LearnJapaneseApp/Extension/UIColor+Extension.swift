//
//  UIColor+Extension.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2025/01/02.
//

import Foundation
import UIKit

extension UIColor {
    
    /// The "PrimaryContainerVariant" asset catalog color resource.
    static let primaryContainerVariant = UIColor(resource: .primaryContainerVariant)
    
    static let canvasVariantHigh = UIColor(resource: .canvasVariantHigh)
}
