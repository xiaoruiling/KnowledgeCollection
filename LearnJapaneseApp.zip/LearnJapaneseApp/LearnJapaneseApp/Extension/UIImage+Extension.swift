//
//  UIImage+Extension.swift
//  RTResources_Example
//
//  Created by Tsuchiya, Hiroma | Hiroma | TDD on 2024/05/23.
//  Copyright © 2024 CocoaPods. All rights reserved.
//

import Foundation
import UIKit

// swiftlint: disable file_length
// workaround for resource catalog generation, ImageResource can't be made public
// https://forums.swift.org/t/xcode15-generated-imageresource-with-public-access/67293
public extension UIImage {
    
    // MARK: - Header
    /// The "HeaderClose" asset catalog image resource.
    static let headerClose = UIImage(resource: .headerClose)

    /// The "HeaderBack" asset catalog image resource.
    static let headerBack = UIImage(resource: .headerBack)
}
