//
//  LearnJapaneseAppApp.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/16.
//

import SwiftUI
import SwiftData

@main
struct LearnJapaneseAppApp: App {
    var body: some Scene {
        WindowGroup {
            BottomNavigationView()
//            TabView {
//                NavigationControllerWrapper {
//                    HomeView()
//                }
//                .tabItem {
//                    Label("Home", systemImage: "house")
//                }
//            }
        }
    }
}
