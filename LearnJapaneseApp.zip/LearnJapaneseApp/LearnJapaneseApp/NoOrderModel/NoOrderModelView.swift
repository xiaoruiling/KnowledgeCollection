//
//  NoOrderView.swift
//  LearnJapaneseApp
//
//  Created by liruiling on 2024/12/18.
//

import SwiftUI

struct NoOrderModelView: View {
    
    @State private var words: [Word] = []

    var body: some View {
        VStack(spacing: .zero) {
            LJNavigationView(
                title: "无序模式",
                navigationViewType: .back
            )
            
            ScrollView {
                VStack(spacing: 16.0) {
                    ForEach(Array(words.enumerated()), id: \.offset) { (index, word) in
                        if index != 0 || (index != (words.count - 1) && index > 0) {
                            Divider()
                        }
                        WordListRowView(
                            index: index + 1,
                            japanese: word.japanese ?? "",
                            phoneticSymbols: word.phoneticSymbols,
                            chinese: word.chinese,
                            example: word.example
                        )
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(16.0)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            Spacer()
        }
        .navigationBarHidden(true)
        .frame(maxWidth: .infinity, alignment: .leading)
        .onAppear {
            loadWordData()
        }
    }
    
    private func loadWordData() {
        Task {
            do {
                words = try LJDataBaseManager.shared.fetchAllWordData()
            } catch {
                
            }
        }
    }
}

#Preview {
    NoOrderModelView()
}
